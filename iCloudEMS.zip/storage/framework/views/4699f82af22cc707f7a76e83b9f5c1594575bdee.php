
<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
        <strong>Whoops!</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
</div>
<?php endif; ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Files Upload form </h4>
        <p class="card-description">
            Files Upload form
        </p>
        <form class="forms-sample" method="POST" action="<?php echo e(route('fileUpload')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

    
          <div class="form-group">
            <label>File upload</label>
            <input type="file" name="file">
          </div> 
          <button type="submit" class="btn btn-primary mr-2">Submit</button>
        </form>
      </div>
    </div>
  </div>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelProjects\iCloudEMS\resources\views/uploadcsv.blade.php ENDPATH**/ ?>