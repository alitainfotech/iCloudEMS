<?php $__env->startSection('pagestyle'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">

<style>
  div.dataTables_wrapper {
        margin-bottom: 3em;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
  <div class="card">
    <div class="card-body">
      <h4 class="card-title">FeeType List</h4>

      <div class="table-responsive">
        <table id="#" class="display" style="width:100%">
          <thead>

            <tr>
                <th>
                    No
                </th>
                <th>
                  BrancheName
                </th>
              <th>
                  CollectionHead
              </th>
              <th>
                  CollectionDescription
              </th>



            </tr>
          </thead>

          <tbody>
                <?php $__currentLoopData = $listFeeCollectionTypeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e((isset($list->branch) && $list->branch->name)  ? $list->branch->name : ""); ?></td>
                        <td><?php echo e($list->collectionhead); ?></td>
                        <td><?php echo e($list->collectionDescription); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('ajaxscript'); ?>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

<script>
$(document).ready(function() {
    $('table.display').DataTable();
} );
</script>

<?php $__env->stopSection(); ?>











<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AD\Desktop\iCloudEMS\resources\views/listFeeCollectionType.blade.php ENDPATH**/ ?>