<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('file')); ?>">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">Uplode File</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('listbranch')); ?>">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">List Branch</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('listFeeCategory')); ?>">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">List FeeCategory</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('listFeeCollectionType')); ?>">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">List FeeCollectionType</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('listFeeType')); ?>">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">List FeeType</span>
        </a>
      </li>



      

    </ul>
  </nav><?php /**PATH /home/hitesh/Documents/alita_infotech/iCouldImage/resources/views/template/sidebar.blade.php ENDPATH**/ ?>