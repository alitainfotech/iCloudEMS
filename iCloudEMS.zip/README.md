
## Installation Laravel

- Extract Folder in any directory.
- Go inside Extract Folder and open the command prompt and run below command.
- composer install 
- php artisan serve

## Database Laravel

- Check root folder inside "iCloudEMS.sql" Database. Import in phpmyadmin.

##  Main Code

- app/Http/Controller/CSVController.php
